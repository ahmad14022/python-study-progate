# Tambahkan parameter ke print_hand
def print_hand(hand, name):
    # Ubah hasil ke '___ memilih: ___'
    print(name + ' memilih: ' + hand)

# Tambahkan argument ke dua ke print_hand
print_hand('Batu', 'Ninja Ken')

# Tambahkan argument ke dua ke print_hand
print_hand('Kertas', 'Komputer')
