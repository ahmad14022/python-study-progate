money = 20
print(money)

# Tambahkan 50 ke variable money
money += 50

# Cetak nilai dari variable money
print(money)