x = 10
# Jika x lebih besar dari 30, cetak 'x lebih besar dari 30'
if x > 30:
  print('x lebih besar dari 30')


money = 5
apple_price = 2
# Jika money sama dengan atau lebih besar dari apple_price, cetak 'Anda dapat membeli apel'
if money >= apple_price:
  print('Anda dapat membeli apel')

