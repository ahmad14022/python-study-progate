# Import class MenuItem menggunakan 'from' 'import'
from menu_item import MenuItem

# Wariskan class MenuItem dan definisikan class Food 
class Food(MenuItem):
    pass